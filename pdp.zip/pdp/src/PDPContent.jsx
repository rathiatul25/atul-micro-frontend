import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';

import { getProductById } from 'home/products';
// import placeAddToCart from 'addtocart/placeAddToCart'; // from other js lib
import PlaceAddToCartMy from 'myaddtocart/placeAddToCartMy'; // from react

export default function PDPContent() {
  const { id } = useParams();
  console.log('id==', useParams());
  // const id = 1;
  const [product, setProduct] = useState(null);

  useEffect(() => {
    if (id) {
      setProduct(getProductById(id));
    } else {
      setProduct(null);
    }
  }, [id]);

  const addToCart = useRef(null);

  useEffect(() => {
    if (addToCart.current) {
      // placeAddToCart(addToCart.current, product.id);
    }
  }, [product]);
  console.log('prod id', product);
  if (!product) return null;

  return (
    <div className="grid grid-cols-2 gap-5">
      <div>
        <div
          style={{
            height: '100px',
            width: '100px',
            background: 'red',
          }}
        ></div>
      </div>
      <div>
        <div className="flex">
          <h1 className="font-bold text-3xl flex-grow">{product.name}</h1>
          <div className="font-bold text-3xl flex-end">{product.price}</div>
        </div>
        {/* <div ref={addToCart}></div> */}
        <PlaceAddToCartMy id="1" />
        <div className="mt-10">{product.description}</div>
      </div>
    </div>
  );
}
