import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import 'remixicon/fonts/remixicon.css';
import './index.scss';
import SafeComponent from './SafeComponent';
import Header from 'home/Header';
import Footer from 'home/Footer';
import PDPContent from './PDPContent';

// import MainLayout from "home/MainLayout";

const App = () => {
  return (
    // <PDPContent />
    <Router>
      <SafeComponent>
        <Header />
      </SafeComponent>
      <Switch>
        <Route exaxt path="/product/:id" component={PDPContent} />
      </Switch>
      <Footer />
    </Router>
  );
};

ReactDOM.render(<App />, document.getElementById('app'));
