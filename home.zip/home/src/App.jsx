import React from 'react';
import ReactDOM from 'react-dom';

import 'remixicon/fonts/remixicon.css';
import './index.scss';
// import Header from './Header';
// import Footer from './Footer';
// import HomeContent from './HomeContent';

import MainLayout from 'home/MainLayout';

// const App = () => {
//   return (
//     <div>
//       <Header />
//       <HomeContent />
//       <Footer />
//     </div>
//   );
// };

// ReactDOM.render(<App />, document.getElementById('app'));
ReactDOM.render(<MainLayout />, document.getElementById('app'));
