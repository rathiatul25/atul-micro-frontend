import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

import { getProducts } from './products';
// import { addToCart, useLoggedIn } from 'cart/cart';
import { addToCart } from 'cart/cart';

export default function HomeContent() {
  // console.log('image1', image1);
  // const loggedIn = useLoggedIn();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    console.log('proddd', getProducts());
    setProducts(getProducts());
  }, []);

  return (
    <div className="grid grid-cols-4 gap-5">
      {products.map((product) => (
        <div key={product.id}>
          <Link to={`/product/${product.id}`}>
            <div
              style={{
                height: '100px',
                width: '100px',
                background: 'red',
              }}
            ></div>
            {/* <img src={product.image} alt={product.name} /> */}
            {/* <img src={image1} /> */}
          </Link>
          <div className="flex">
            <div className="flex-grow font-bold">
              <Link to={`/product/${product.id}`}>
                <a>{product.name}</a>
              </Link>
            </div>
          </div>
          <div className="text-sm mt-4">{product.description}</div>
          <div className="text-right mt-2">
            <button
              className="bg-blue-500 hover:bg-blue-700 text-white text-sm font-bold py-2 px-4 rounded"
              onClick={() => addToCart(product.id)}
              id={`addtocart_${product.id}`}
            >
              Add to Cart
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
