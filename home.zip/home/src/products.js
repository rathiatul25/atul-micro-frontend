// const API_SERVER = "http://localhost:8080";

// export const getProducts = () =>
//   fetch(`${API_SERVER}/products`).then((res) => res.json());

// export const getProductById = (id) =>
//   fetch(`${API_SERVER}/products/${id}`).then((res) => res.json());

// export const currency = new Intl.NumberFormat("en-US", {
//   style: "currency",
//   currency: "USD",
// });

export const getProducts = () => [
  {
    id: 1,
    name: 'Mouse',
    description: 'Mouse description',
    price: 10,
  },
  {
    id: 2,
    name: 'Keyboard',
    description: 'Keyboard description',
    price: 10,
  },
];

export const getProductById = (id) => {
  return {
    id: 1,
    name: 'Mouse',
    description: 'Mouse description',
    price: 10,
  };
};
