module.exports = {
  testEnvironment: "jsdom",
};
