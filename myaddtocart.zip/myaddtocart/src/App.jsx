import React from 'react';
import ReactDOM from 'react-dom';

const App = () => {
  return <div>test</div>;
};

ReactDOM.render(<App />, document.getElementById('app'));
