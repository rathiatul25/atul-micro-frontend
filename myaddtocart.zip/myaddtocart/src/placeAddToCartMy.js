import React from 'react';

import MyAddToCart from './MyAddToCart';

export default function placeAddToCartMy(id) {
  return <MyAddToCart id={id} />;
}
