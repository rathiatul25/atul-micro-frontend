import React from 'react';

export default ({ id }) => {
  return (
    <div>
      <button
        onClick={() => addToCart(id)}
        className="bg-red-900 text-white py-2 px-5 rounded-md text-sm mt-5"
      >
        Add To Cart
      </button>
    </div>
  );
};
