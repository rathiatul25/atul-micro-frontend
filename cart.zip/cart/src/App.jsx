import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import 'remixicon/fonts/remixicon.css';
import './index.scss';
import Header from 'home/Header';
import Footer from 'home/Footer';
import CartContent from './CartContent';

// import MainLayout from "home/MainLayout";

// ReactDOM.render(<MainLayout />, document.getElementById("app"));
const App = () => {
  return (
    <Router>
      <div>
        <Header />
        <Switch>
          <Route exact path="/cart" component={CartContent} />
        </Switch>
        {/* <CartContent /> */}
        <Footer />
      </div>
    </Router>
  );
};

ReactDOM.render(<App />, document.getElementById('app'));
